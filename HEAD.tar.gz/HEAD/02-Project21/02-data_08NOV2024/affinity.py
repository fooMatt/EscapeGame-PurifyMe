def Affinity():
    explanation = '''
    A Ni-NTA column is a type of affinity chromatography.
    It works through Ni ions bound to beads in the column.
    A poly-histidine tag is fused to your protein of interest.
    This tag binds to the Ni ions through the formation of a coordination complex.
    Other proteins (not tagged with His) flow through. 
    You can collect your protein afterwards by eluting it with imidazole.
    '''
    print(explanation)
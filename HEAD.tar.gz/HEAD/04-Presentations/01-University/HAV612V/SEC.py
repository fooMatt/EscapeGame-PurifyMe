def SizeExclusion() :
    explanation = '''
    Size Exclusion Chromatography utilises porous beads in a column.
    Smaller proteins pass through many pores in the beads and their descent in the column is slowed down.
    Larger proteins pass through fewer pores in the beads and their descent is not slowed down as much.
    Larger proteins thus flow through earlier than smaller proteins, allowing proteins to be separated by their size.
    Very large proteins may not be slowed by the porous beads at all. 
    This is the size exclusion limit - all proteins over this limit will elute in the void volume.
    SEC gives better resolution with smaller sample volume - consider using this method in a second step!
    '''
    print(explanation)

def ExclusionEval(exclusion_limit):
# if exclusion limit of column is smaller than protein MW, protein will not be retained and will elute in the void volume with other large proteins
    exclusion_limit = exclusion_limit.upper()
    if exclusion_limit=="C": 
        print("Your protein is within the exclusion limit. Good job!\n")
        return True
    else:
        print("Your protein is too large for this column and eluted in the void volume. Try again.\n")
        return False
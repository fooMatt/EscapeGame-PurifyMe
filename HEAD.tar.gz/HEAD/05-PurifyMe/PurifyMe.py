# import modules from other files, define functions
import cation_xchange
import anion_xchange
import SEC
import affinity
import time

# introduction : set the context of the activity
print("Welcome to Activity #2! I am a computer programme designed to help you with protein purification protocols.")
time.sleep(1)
print("My programme consists of 2 parts:\n1. I will explain the different chromatography methods available in our lab\n2. I will ask you for your choice of column(s) and tell you your results.\n")
time.sleep(1)
print("Let's begin!")
time.sleep(1)
# part 1 : explain what each column does when user chooses it
Running1 = True
while Running1:
    explain_column = input("Which column would you like me to explain to you?\nChoose cation, anion, SEC, or Ni-NTA ")
    
    if explain_column == "cation":
        cation_xchange.CationExchange()
    elif explain_column == "anion":
        anion_xchange.AnionExchange()
    elif explain_column == "SEC" or explain_column == "sec":
        SEC.SizeExclusion()
    elif explain_column == "Ni-NTA" or explain_column == "ni-nta":
        affinity.Affinity()
    else:
        print("I didn't recognise your answer...\nMake sure you typed it exactly as it was in the prompt (including the cases)!")
    
    end = input("Would you like to exit the explanation part and make your choice of columns? (Y/N) ")
    if end.upper() == "Y":
        Running1 = False
        print("Now starting part 2: making your choice of column(s)\n")
        time.sleep(1)
    else:
        pass

# part 2 : ask user for input on which columns they want to use
Running2 = True
Intro2 = True
while Running2:
    while Intro2:
        print("\nBased on my explanation in part 1, you will now have to choose which columns (maximum 2) you want to use.")
        time.sleep(1)
        print("Please input one of the following: cation, anion, SEC, Ni-NTA or NA if you don't wish to use a column.")
        time.sleep(1)
        print("Pay attention to the case and spelling for your choice of column!")
        Intro2 = False

    # ask user for details about 1st column to be used
    column1 = input("What is your choice for the first column? (cation, anion, SEC, Ni-NTA or NA)\n")
    # request more details if ion exchange or SEC are used
    if column1 == "cation":
        bufferpH = input("Please input the pH of your buffer.\n")
        if (cation_xchange.cat_pHeval(bufferpH)):
            pass
        else:
            column1 = ""
            Intro2 = True
    elif column1 == "anion":
        bufferpH = input("Please input the pH of your buffer.\n")
        if (anion_xchange.an_pHeval(bufferpH)):
            pass
        else:
            column1 = ""
            Intro2 = True
    elif column1 == "SEC" or column1 == "sec":
        exclusion_limit = input("Please choose the exclusion limit of the SEC column.\nWe have columns for the following ranges:\n(A) <10 kDa\n(B) 3-70 kDa\n(C) 10-600 kDa.\n")
        if (SEC.ExclusionEval(exclusion_limit)):
            pass
        else:
            column1 = ""
            Intro2 = True

    # ask user for details about 2nd column to be used
    column2 = input("What is your choice for the second column? (cation, anion, SEC, Ni-NTA or NA)\n")
    # request more details if ion exchange or SEC are used
    if column2 == "cation":
        bufferpH = input("Please input the pH of your buffer.\n")
        if (cation_xchange.cat_pHeval(bufferpH)):
            pass
        else:
            column2 = ""
            Intro2 = True
    elif column2 == "anion":
        bufferpH = input("Please input the pH of your buffer.\n")
        if (anion_xchange.an_pHeval(bufferpH)):
            pass
        else:
            column2 = ""
            Intro2 = True
    elif column2 == "SEC" or column2 == "sec":
        exclusion_limit = input("Please choose the exclusion limit of the SEC column.\nWe have columns for the following ranges:\n(A) <10 kDa\n(B) 3-70 kDa\n(C) 10-600 kDa.\n")
        if (SEC.ExclusionEval(exclusion_limit)):
            pass
        else:
            column2 = ""
            Intro2 = True

    # check if column1 and column2 are correct
    if column1 == "anion" and (column2 == "SEC" or column2 == "sec"):
        print("Congratulations! You purified your protein. The secret code is Z8.\n")
        Running2 = False
    else:
        print("You failed to purify your proteins with this combination of columns.\nEither the choice/order of columns was wrong, or some columns failed. Try again!\n")
        Intro2 = True
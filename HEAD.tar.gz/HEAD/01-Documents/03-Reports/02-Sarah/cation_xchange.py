HTTpI = 5.81

def CationExchange() :
    explanation = '''
    Cation exchange chromatography utilises beads with negative charges.
    Positively charged molecules (i.e. cations) are attracted to the beads and are retained in the column.
    Anions flow through and are collected first.
    To use this method, your protein of interest must be positively charged at the pH of the buffer you are using.
    By changing the pH or the salt concentration, the protein of interest can be eluted from the column. 
    '''
    print(explanation)

def cat_pHeval(bufferpH):
    if float(bufferpH) < HTTpI: # protein is positively charged when pH of buffer is lower than pI
        print("Your protein is positively charged at this pH. Good job!\n")
        return True
    else: # if pH > pI, protein is negatively charged and won't be retained by cation exchange column
        print("Your protein is negatively charged at this pH. You lost your sample in the flow through.\n")
        return False